<?php
// Simpan file ini sebagai process_login.php

// Proses login jika formulir dikirimkan
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Gantilah ini dengan validasi pengguna dari database Anda
    $valid_admin_username = "";
    $valid_admin_password = "";

    $input_username = $_POST["username"];
    $input_password = $_POST["password"];

    // Periksa kecocokan username dan password
    if ($input_username == $valid_admin_username && $input_password == $valid_admin_password) {
        // Redirect ke halaman admin jika login berhasil
        header("Location: admin_dashboard.php");
        exit();
    } else {
        // Tampilkan pesan kesalahan jika login gagal
        echo "Login gagal. Silakan coba lagi.";
    }
}
?>

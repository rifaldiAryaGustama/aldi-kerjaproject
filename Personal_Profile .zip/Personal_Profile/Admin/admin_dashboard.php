<?php
// Simpan file ini sebagai admin_dashboard.php

// Gantilah ini dengan mekanisme otentikasi sesuai kebutuhan Anda
session_start();
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: login.html");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
</head>
<body>
    <h2>Selamat datang, Admin!</h2>
    <p>Ini adalah halaman admin Anda.</p>
    <a href="logout.php">Logout</a>
</body>
</html>

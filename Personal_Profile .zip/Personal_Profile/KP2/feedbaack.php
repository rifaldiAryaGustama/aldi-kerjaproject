<?php



// buat query
$sql = "INSERT INTO feedback (email, comments) VALUE ('$email', '$comments')";
$query = mysqli_query($db, $sql);

?>